package assignment3_2014302580024;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataBases2014302580024 {
	private final String driver = "com.mysql.jdbc.Driver";
	private String userName = "root";
	private String password = "my sql admin -u root password";
	private final String url = "jdbc:mysql//localhost:3306/";
	public Connection conn = null;
    public Statement statement = null;

    public DataBases2014302580024(){
    	System.out.println("Start to make connection to database...");
    	System.out.println("Please input the password");
      try {
			Class.forName(driver);
		} catch (ClassNotFoundException e1) {
			
			e1.printStackTrace();
		}

           try {
			conn = DriverManager.getConnection(url, userName, password);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

    }

	public void writeSQL(String sql){
		
		 try{
	            Statement statement = conn.createStatement();
	            statement.execute(sql);
	        }catch (Exception e){
	            e.printStackTrace();
	        }

	}

}
