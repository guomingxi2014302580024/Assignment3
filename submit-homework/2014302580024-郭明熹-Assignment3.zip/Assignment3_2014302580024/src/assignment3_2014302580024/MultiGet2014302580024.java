package assignment3_2014302580024;

import java.util.ArrayList;
import org.jsoup.select.*;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class MultiGet2014302580024 implements Runnable{
    public  ArrayList<ArrayList<String>> UrlList2 = new ArrayList<ArrayList<String>>();
    private int counter = 0;
    public MultiGet2014302580024(ArrayList<ArrayList<String>> UrlList2){
    	   this.UrlList2 = UrlList2;
    }
      DataBases2014302580024 dataBases2=new DataBases2014302580024();
      public void run(){
    	  try{
    	  for (int i = this.counter;i<UrlList2.size()-3;i++){
              if (this.counter<UrlList2.size()-3){
                  this.counter++;
              }
              Document everyOne;

			everyOne = Jsoup.connect(UrlList2.get(i).get(0)).get();

              String email = everyOne.getElementById("contactinfo").getElementsByTag("a").text();
              String intro = everyOne.getElementsByClass("titles").get(0).nextElementSibling().text();

              dataBases2.writeSQL("insert into teacher values(" +"'"+ UrlList2.get(i).get(1)+"'" + "," +"'"+ email+"'" + "," +"'"+ intro +"'"+ ");");
              UrlList2.get(i).add(2, email);
              UrlList2.get(i).add(3, intro);
          }
    	  }catch (Exception e){
              e.printStackTrace();
          }

      }
}
