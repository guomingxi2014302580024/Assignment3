 package assignment3_2014302580024;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class GetTeacher2014302580024 {
	public static String url="http://www.wpi.edu/academics/cs/research-interests.html";
	public ArrayList<ArrayList<String>> UrlList2 = new ArrayList<ArrayList<String>>();
	ArrayList<String> oneTeacher = new ArrayList<>(2);


public GetTeacher2014302580024(){

  }

public void GetList() throws IOException{

   // HttpRequest assignment3_2014302580024= new HttpRequest(url,"GET");
   //
   // if(assignment3_2014302580024.ok()){
   // le input=new File("teachers.html");
   // assignment3_2014302580024.receive(input);

   Document doc=Jsoup.connect(url).get();
   // System.out.println(input);
   Elements teacherDiv=doc.select("div.half");
   Elements teacherUrlList=teacherDiv.select("a");
   for (int i=0;i<teacherUrlList.size();i++) {
       oneTeacher.add(0, teacherUrlList.get(i).attr("href"));
       oneTeacher.add(1, teacherUrlList.get(i).attr("title"));
       UrlList2.add(oneTeacher);
   }

}
}
