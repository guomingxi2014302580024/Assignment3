 package assignment3_2014302580024;

import org.jsoup.*;
import org.jsoup.select.*;
import org.jsoup.nodes.*;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import java.lang.System;
import java.lang.Thread;

public class Main2014302580024 {
	 static String url="http://www.wpi.edu/academics/cs/research-interests.html";


	 public static void main(String[] args) throws IOException{

	 	long singleStartTime = System.currentTimeMillis();

	 	getTeacher get_teacher=new getTeacher(url);
	 	get_teacher.GetList();
	 	get_teacher.parseHTML();

	 	GetTeacher2014302580024 getteacher=new GetTeacher2014302580024();
	 	getteacher.GetList();
	 	MultiGet2014302580024 multiget=new MultiGet2014302580024(getteacher.UrlList2);
	 	  for (int i=0;i<4;i++){
	 	      (new Thread(multiget)).start();
	 	  }

	 	Long mutiStartTime=System.currentTimeMillis();
	 	long endTime=System.currentTimeMillis();
	 	long singleTime=mutiStartTime-singleStartTime;
	 	long mutiTime=endTime-mutiStartTime;
	 	System.out.println("���߳�ִ��ʱ�䣺"+singleTime);
	 	System.out.println("���߳�ִ��ʱ�䣺"+mutiTime);
	 }
	public static class getTeacher{

		private String email;
		private String intro;
		public ArrayList<ArrayList<String>> UrlList = new ArrayList<ArrayList<String>>();
		ArrayList<String> oneTeacher = new ArrayList<>(2);
		private String URL;


	public getTeacher(String URL){
		this.URL=URL;
	}

    public void GetList() throws IOException{

	//    HttpRequest assignment3_2014302580024= new HttpRequest(url,"GET");

	//    if(assignment3_2014302580024.ok()){
	// 	File input=new File("teachers.html");
	//    assignment3_2014302580024.receive(input);

	   Document doc=Jsoup.connect(URL).get();
	//    System.out.println(input);
	   Elements teacherDiv=doc.select("div.half");
	   Elements teacherUrlList=teacherDiv.select("a");
	   for (int i=0;i<teacherUrlList.size();i++) {
           oneTeacher.add(0, teacherUrlList.get(i).attr("href"));
           oneTeacher.add(1, teacherUrlList.get(i).attr("title"));
           UrlList.add(oneTeacher);
       }

    }
    public void parseHTML() throws IOException{

    	DataBases2014302580024 dataBases=new DataBases2014302580024();
    	int length=UrlList.size();

    	 for (int i=0;i<length;i++){
    		 Document everyTeacher=Jsoup.connect(UrlList.get(i).get(0)).get();
    		 email=everyTeacher.select("contactinfo").select("a").text();
    		 intro=everyTeacher.getElementsByClass("titles").get(0).nextElementSibling().text();
    		 dataBases.writeSQL("insert into teacher values(" +"'"+ UrlList.get(i).get(1)+"'" + "," +"'"+ email+"'" + "," +"'"+ intro +"'"+ ");");
    		 UrlList.get(i).add(2,email);
             UrlList.get(i).add(3,intro);
    	 }
    }

	}







}
